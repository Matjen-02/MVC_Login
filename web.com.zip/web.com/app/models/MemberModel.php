<?php 

class MemberModel {

    private $table = 'tb_member';
    private $db;

    public function __construct(){
        $this->db = new Database;
    }


    public function getAllMember(){
        $this->db->query('SELECT * FROM ' . $this->table);
        return $this->db->resultSet();
        
    }

    public function getMemberById($id){
        $this->db->query('SELECT * FROM ' . $this->table . ' WHERE id=:id');
        $this->db->bind('id', $id);
        return $this->db->single();
    }

    public function tambahDataMember($data){
        $query = "INSERT INTO tb_member VALUES ('', :nomor, :nama, :nim, :email, :jns_kelamin)";

        $this->db->query($query);
        $this->db->bind('nomor', $data['nomor']);
        $this->db->bind('nama', $data['nama']);
        $this->db->bind('nim', $data['nim']);
        $this->db->bind('email', $data['email']);
        $this->db->bind('jns_kelamin', $data['jns_kelamin']);

        $this->db->execute();
        return $this->db->rowCount();

    }

    public function hapusDataMember($id){
        $query = "DELETE FROM tb_member WHERE id = :id";
        $this->db->query($query);
        $this->db->bind('id', $id);
        $this->db->execute();
        return $this->db->rowCount();

    }

    public function editDataMember($data){
        $query = "UPDATE tb_member SET 
        nomor = :nomor,
        nama = :nama,
        nim = :nim,
        email = :email,
        jns_kelamin = :jns_kelamin
        WHERE id = :id";

        $this->db->query($query);
        $this->db->bind('nomor', $data['nomor']);
        $this->db->bind('nama', $data['nama']);
        $this->db->bind('nim', $data['nim']);
        $this->db->bind('email', $data['email']);
        $this->db->bind('jns_kelamin', $data['jns_kelamin']);
        $this->db->bind('id', $data['id']);

        $this->db->execute();
        return $this->db->rowCount();

    }


    public function cariDataMember(){
        $keyword = $_POST['keyword'];
        $query = "SELECT * FROM tb_member WHERE nama LIKE :keyword";
        $this->db->query($query);
        $this->db->bind('keyword', "%$keyword%");
        return $this->db->resultSet();
    }

}