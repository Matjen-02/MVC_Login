<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Halaman <?= $data['judul']; ?></title>

    <!-- Ikon -->
    <script src="https://unpkg.com/feather-icons"></script>

    <!-- Style -->
    <link rel="stylesheet" href="css/Web.css" />
</head>
<link rel="icon" href="<?= BASEURL; ?> /img/tif.png" type="jpg/png">

<!-- Navbar -->

<!-- <body> -->
<nav class="navbar">
    <a href="<?= BASEURL; ?>/home" class="navbar-logo">TEKNIK <span>INFORMATIKA 2022</span></a>
    <div class="navbar-nav">
        <a href="<?= BASEURL; ?>/home">BERANDA</a>
        <a href="<?= BASEURL; ?>/about">VISI MISI</a>
        <a href="<?= BASEURL; ?>/admin">MEMBER</a>
        <a href="<?= BASEURL; ?>/kontak">KONTAK</a>
    </div>

    <div class="navbar-extra">
        <!-- <a href="#kontak" id="cari"><i data-feather="chevrons-down"></i></a> -->
        <a href="<?= BASEURL; ?>/login" id="user"><i data-feather="log-out"></i></a>
        <a href="#" id="menu"><i data-feather="menu"></i></a>
    </div>
</nav> -->
<!-- Navbar Selesai -->
<!-- Visi Misi start -->
<section id="visi" class="visi">
    <h2>VISI MISI</h2>
    <h2>TEKNIK <span>INFORMATIKA</span></h2>

    <div class="row">
        <div class="visi-img">
            <img src="img/tif.png" alt="VISI MISI" />
        </div>
        <div class="content">
            <div class="con1">
                <h3>VISI</h3>
                <p><b>
                        "Terwujudnya Program Studi Teknik Informatika yang Unggul,
                        Inovatif dan Terkemuka Berbasis Teknologi Terapan Pada Tahun
                        2032".</b>
                </p>
            </div><br><br>
            <div class="con2">
                <h3>MISI</h3>
                <p>
                    Program Studi D3 Teknik Informatika Politeknik Kampar telah
                    menjabarkan Visi Program Studi menjadi rumusan Misi Program Studi
                    yaitu :
                </p>
                <p>
                    1. Menyelenggarakan Pendidikan Vokasional untuk mencetak tenaga
                    kerja yang berkualitas.
                </p>
                <p>
                    2. Mengembangkan Teknologi Terapan melalui penelitian untuk
                    mendukung perkembangan industri, khususnya industri sawit.
                </p>
                <p>
                    3. Berperan aktif memecahkan masalah permasalahan masyarakat
                    melalui pengabdian masyarakat.
                </p>
                <p>
                    4. Menjalin kolaborasi dengan dunia usaha dan industri untuk
                    menghadapi persaingan global.
                </p>
            </div>
        </div>
    </div>
</section>
<!-- Visi Misi end -->

<!-- footer start-->
<footer>
    <div class="social">
        <a href="https://www.instagram.com/tifb_22?igsh=NTVmejd4bWJiYWVi"><i data-feather="instagram"></i></a>
        <a href="https://wa.me/qr/LGRPSDS6FPBBK1"><i data-feather="phone-call"></i></a>
        <a href="https://github.com/Matjen-02"><i data-feather="github"></i></a>
    </div>

    <div class="links">
        <a href="<?= BASEURL; ?>/home">BERANDA</a>
        <a href="<?= BASEURL; ?>/about">VISI MISI</a>
        <a href="<?= BASEURL; ?>/admin">MEMBER</a>
        <a href="<?= BASEURL; ?>/kontak">KONTAK</a>
    </div>

    <div credit>
        <p>
            Created By
            <a href="https://instagram.com/matjen_alfarizi?utm_source=qr&igshid=MzNlNGNkZWQ4Mg==">Teknik
                Informatika 2022</a>
            . | &copy; 2024.
        </p>
    </div>
</footer>
<!-- footer end -->

<!-- Ikon -->
<script>
feather.replace();
</script>

<!-- My JS -->
<script src="js/Web.js"></script>
</body>

</html>