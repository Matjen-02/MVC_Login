<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title><?= $data['judul']; ?></title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script src="https://unpkg.com/feather-icons"></script>
    <link rel="stylesheet" href="css/Web.css" />

    <link rel="icon" href="<?= BASEURL; ?> /img/tif.png" type="jpg/png">
</head>

<body class="hold-transition sidebar-mini">
    <!-- Site wrapper -->
    <div class="wrapper">
        <!-- Navbar -->

        <nav class="navbar">
            <a href="<?= BASEURL; ?>/home" class="navbar-logo">TEKNIK <span>INFORMATIKA 2022</span></a>
            <div class="navbar-nav">
                <a href="<?= BASEURL; ?>/home">BERANDA</a>
                <a href="<?= BASEURL; ?>/about">VISI MISI</a>
                <a href="<?= BASEURL; ?>/admin">MEMBER</a>
                <a href="<?= BASEURL; ?>/kontak">KONTAK</a>
            </div>

            <div class="navbar-extra">
                <!-- <a href="#kontak" id="cari"><i data-feather="chevrons-down"></i></a> -->
                <a href="<?= BASEURL; ?>/login" id="user"><i data-feather="log-out"></i></a>
                <a href="#" id="menu"><i data-feather="menu"></i></a>
            </div>
        </nav>

        <body>

            <style>
            body {
                background-image: url('<?= BASEURL; ?> /img/z3.JPG');
                background-size: cover;
                background-position: center;
                background-repeat: no-repeat;
                height: 100vh;
                margin: 0;
            }
            </style>


            <section class="hero" id="profil">
                <main class="content">
                    <h1>Selamat Datang di Profil Teknik <span>Informatika 2022</span></h1>
                    <p><b>
                            Terwujudnya Program Studi Teknik Informatika yang Unggul, Inovatif dan
                            Terkemuka Berbasis Teknologi Terapan Pada Tahun 2032. </b>
                    </p>
                    <!-- <p>
                    <a href="#" class="cta">Kunjungi Profil</a>
                </p> -->
                </main>
            </section>
            <!-- Profil end -->

            <!-- footer start-->
            <footer>
                <div class="social">
                    <a href="https://www.instagram.com/tifb_22?igsh=NTVmejd4bWJiYWVi"><i
                            data-feather="instagram"></i></a>
                    <a href="https://wa.me/qr/LGRPSDS6FPBBK1"><i data-feather="phone-call"></i></a>
                    <a href="https://github.com/Matjen-02"><i data-feather="github"></i></a>
                </div>

                <div class="links">
                    <a href="<?= BASEURL; ?>/home">BERANDA</a>
                    <a href="<?= BASEURL; ?>/about">VISI MISI</a>
                    <a href="<?= BASEURL; ?>/admin">MEMBER</a>
                    <a href="<?= BASEURL; ?>/kontak">KONTAK</a>
                </div>

                <div credit>
                    <p>
                        Created By
                        <a href="https://instagram.com/matjen_alfarizi?utm_source=qr&igshid=MzNlNGNkZWQ4Mg==">Teknik
                            Informatika 2022</a>
                        . | &copy; 2024.
                    </p>
                </div>
            </footer>
            <!-- footer end -->

            <!-- Ikon -->
            <script>
            feather.replace();
            </script>

            <!-- My JS -->
            <script src="<?= BASEURL; ?>/js/script.js"></script>
            <script src="js/Web.js"></script>

        </body>

</html>