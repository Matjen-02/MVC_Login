<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title><?= $data['judul']; ?></title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Font Awesome -->
    <link rel="stylesheet" href="<?= BASEURL; ?>/plugins/fontawesome-free/css/all.min.css">
    <!-- Ionicons -->
    <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
    <script src="https://unpkg.com/feather-icons"></script>
    <!-- overlayScrollbars -->
    <link rel="stylesheet" href="<?= BASEURL; ?>/dist/css/adminlte.min.css">

    <!-- Google Font: Source Sans Pro -->
    <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
    <link rel="stylesheet" href="css/Web.css" />

    <link rel="icon" href="<?= BASEURL; ?> /img/tif.png" type="jpg/png">
</head>

<body class="hold-transition sidebar-mini">
    <!-- Site wrapper -->
    <div class="wrapper">
        <!-- Navbar -->

        <nav class="navbar">
            <a href="<?= BASEURL; ?>/home" class="navbar-logo">TEKNIK <span>INFORMATIKA 2022</span></a>
            <div class="navbar-nav">
                <a href="<?= BASEURL; ?>/home">BERANDA</a>
                <a href="<?= BASEURL; ?>/about">VISI MISI</a>
                <a href="<?= BASEURL; ?>/admin">MEMBER</a>
                <a href="<?= BASEURL; ?>/kontak">KONTAK</a>
            </div>

            <div class="navbar-extra">
                <!-- <a href="#kontak" id="cari"><i data-feather="chevrons-down"></i></a> -->
                <a href="<?= BASEURL; ?>/login" id="user"><i data-feather="log-out"></i></a>
                <a href="#" id="menu"><i data-feather="menu"></i></a>
            </div>
        </nav>
        <!-- Kontak start -->
        <section id="kontak" class="kontak">
            <h2>KONTAK <span>KAMI</span></h2>
            <p></p>

            <div class="row">
                <iframe
                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3989.749823243732!2d101.04357427395834!3d0.33573589966096945!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x31d5144212fb21f7%3A0xb41facf686ab859c!2sPoliteknik%20Kampar!5e0!3m2!1sid!2sid!4v1703777346887!5m2!1sid!2sid"
                    allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade" class="map"></iframe>
                <form action="">
                    <div class="input-group">
                        <i data-feather="user"></i>
                        <input type="text" placeholder="Nama" />
                    </div>
                    <div class="input-group">
                        <i data-feather="phone"></i>
                        <input type="text" placeholder="No Handphone" />
                    </div>
                    <div class="input-group">
                        <i data-feather="at-sign"></i>
                        <input type="text" placeholder="Email" />
                    </div>
                    <div class="input-group">
                        <i data-feather="mail"></i>
                        <input type="text" placeholder="Pesan" />
                    </div>
                    <button type="submit" class="btn">Kirim Pesan</button>
                </form>
            </div>
        </section>
        <!-- Kontak end -->
        <!-- footer start-->
        <footer>
            <div class="social">
                <a href="https://www.instagram.com/tifb_22?igsh=NTVmejd4bWJiYWVi"><i data-feather="instagram"></i></a>
                <a href="https://wa.me/qr/LGRPSDS6FPBBK1"><i data-feather="phone-call"></i></a>
                <a href="https://github.com/Matjen-02"><i data-feather="github"></i></a>
            </div>

            <div class="links">
                <a href="<?= BASEURL; ?>/home">BERANDA</a>
                <a href="<?= BASEURL; ?>/about">VISI MISI</a>
                <a href="<?= BASEURL; ?>/admin">MEMBER</a>
                <a href="<?= BASEURL; ?>/kontak">KONTAK</a>
            </div>

            <div credit>
                <p>
                    Created By
                    <a href="https://instagram.com/matjen_alfarizi?utm_source=qr&igshid=MzNlNGNkZWQ4Mg==">Teknik
                        Informatika 2022</a>
                    . | &copy; 2024.
                </p>
            </div>
        </footer>
        <!-- footer end -->

        <!-- Ikon -->
        <script>
        feather.replace();
        </script>

        <!-- My JS -->
        <!-- jQuery -->
        <script src="<?= BASEURL; ?>/plugins/jquery/jquery.min.js"></script>
        <!-- Bootstrap 4 -->
        <script src="<?= BASEURL; ?>/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
        <!-- AdminLTE App -->
        <script src="<?= BASEURL; ?>js/adminlte.min.js"></script>
        <!-- AdminLTE for demo purposes -->
        <script src="<?= BASEURL; ?>js/demo.js"></script>
        <script src="<?= BASEURL; ?>/js/script.js"></script>
        <script src="js/Web.js"></script>

</body>

</html>