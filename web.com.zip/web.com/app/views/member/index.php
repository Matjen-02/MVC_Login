<div class="container mt-3">

    <div class="row">
        <div class="col-lg-6">
            <?php Flasher::flash(); ?>
        </div>

    </div>

    <div class="row mb-3">
        <div class="col-lg-6">
            <button type="button" class="btn btn-dark tombolTambahData" data-bs-toggle="modal"
                data-bs-target="#formModal">
                Tambah Data Member
            </button>
        </div>
    </div>

    <div class="row mb-">
        <div class="col-lg-6">
            <form action="<?= BASEURL; ?>/member/cari" method="post">
                <div class="input-group mb-3">
                    <input type="text" class="form-control" placeholder="Cari Member..." name="keyword" id="keyword"
                        autocomplete="off">
                    <button class="btn btn-dark" type="submit" id="tombolCari">Cari</button>
                </div>

            </form>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-6">



            <h3>Daftar Member</h3>


            <ul class="list-group">
                <?php foreach ( $data['mbr'] as $mbr ) : ?>

                <!-- menampilkan nama daftar member -->
                <li class="list-group-item">
                    <?= $mbr['nomor'] . ' . ' .  $mbr['nama']; ?>

                    <a href="<?= BASEURL; ?>/member/hapus/<?= $mbr['id']; ?>"
                        class="badge text-bg-danger float-end ms-2" onclick="return confirm('Yakin ? ');">hapus</a>

                    <a href="<?= BASEURL; ?>/member/edit/<?= $mbr['id']; ?>"
                        class="badge text-bg-success float-end ms-2 tampilModalEdit" data-bs-toggle="modal"
                        data-bs-target="#formModal" data-bs-id="<?= $mbr['id']; ?>">edit</a>

                    <!-- <a href=" <?= BASEURL; ?>/member/bio/<?= $mbr['id']; ?>"
                        class="badge text-bg-primary float-end ms-2">Bio</a> -->
                </li>
                <?php endforeach; ?>

            </ul>

        </div>

    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="formModal" tabindex="-1" aria-labelledby="formModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h1 class="modal-title fs-5" id="formModalLabel">Tambah Data Member</h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form action="<?= BASEURL; ?>/member/tambah" method="post">
                    <input type="hidden" name="id" id="id">

                    <div class="mb-3">
                        <label for="no" class="form-label">Nomor</label>
                        <input type="text" class="form-control" id="nomor" name="nomor">
                    </div>
                    <div class="mb-3">
                        <label for="nama" class="form-label">Nama</label>
                        <input type="text" class="form-control" id="nama" name="nama">
                    </div>
                    <div class="mb-3">
                        <label for="nim" class="form-label">Nim</label>
                        <input type="number" class="form-control" id="nim" name="nim">
                    </div>
                    <div class="mb-3">
                        <label for="email" class="form-label">Email</label>
                        <input type="email" class="form-control" id="email" name="email">
                    </div>

                    <div class="form-group mb-3">
                        <label for="jns_kelamin">Jenis Kelamin</label>
                        <select class="form-select" id="jns_kelamin" name="jns_kelamin">
                            <option value="Laki-laki">Laki-laki</option>
                            <option value="Perempuan">Perempuan</option>
                        </select>
                    </div>

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-dark">Tambah Data</button>
                </form>
            </div>
        </div>
    </div>
</div>
<br><br><br>