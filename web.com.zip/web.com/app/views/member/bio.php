<style>
body {
    background-image: url('<?= BASEURL; ?> /img/z3.JPG');
    background-size: cover;
    background-position: center;
    background-repeat: no-repeat;
    height: 100vh;
    margin: 0;
}
</style>

<div class="container mt-2">
    <div class="card" style="width: 18rem;">
        <div class="card-body bg-dark text-light">
            <h5 class="card-title"><?= $data['mbr']['nomor'] . ' . ' . $data['mbr']['nama']; ?></h5>
            <h6 class="card-subtitle mb-2 text"><?= $data['mbr']['nim']; ?></h6>
            <p class="card-text"><?= $data['mbr']['email']; ?></p>
            <p class="card-text"><?= $data['mbr']['jns_kelamin']; ?></p>
            <a href="<?= BASEURL; ?>/admin" class="card-link">Kembali</a>
            <!-- <a href="#" class="card-link">Another link</a> -->
        </div>
    </div>

</div>