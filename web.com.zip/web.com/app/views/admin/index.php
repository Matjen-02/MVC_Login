<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Halaman <?= $data['judul']; ?></title>
    <!-- <link rel="stylesheet" href="<?= BASEURL; ?>/css/bootstrap.css"> -->
    <!-- Ikon -->
    <script src="https://unpkg.com/feather-icons"></script>

    <!-- Style -->
    <link rel="stylesheet" href="css/Web.css" />
</head>
<link rel="icon" href="<?= BASEURL; ?> /img/tif.png" type="jpg/png">

<!-- Navbar -->

<body>
    <nav class="navbar">
        <a href="<?= BASEURL; ?>/home" class="navbar-logo">TEKNIK <span>INFORMATIKA 2022</span></a>
        <div class="navbar-nav">
            <a href="<?= BASEURL; ?>/home">BERANDA</a>
            <a href="<?= BASEURL; ?>/about">VISI MISI</a>
            <a href="<?= BASEURL; ?>/admin">MEMBER</a>
            <a href="<?= BASEURL; ?>/kontak">KONTAK</a>
        </div>

        <div class="navbar-extra">
            <!-- <a href="#kontak" id="cari"><i data-feather="chevrons-down"></i></a> -->
            <a href="<?= BASEURL; ?>/member" id="user"><i data-feather="edit"></i></a>
            <a href="<?= BASEURL; ?>/login" id="user"><i data-feather="log-out"></i></a>
            <a href="#" id="menu"><i data-feather="menu"></i></a>
        </div>
    </nav>
    <!-- Navbar Selesai -->
    <!-- Member start -->
    <section id="member" class="member">
        <h2>THIS IS ADMIN <span>TIF 22</span></h2>
        <div class="row">

            <div class="member-card">
                <img src="img/dinda.jpg" alt="Dinda" class="menu-card-img" />
                <h5 class="menu-card-title">Dinda Dwi Wanni Putri</h5>
                <p class="menu-card-nim">22323012</p>
            </div>

            <div class="member-card">
                <img src="img/fadilah.jpg" alt="Fadilah" class="menu-card-img" />
                <h5 class="menu-card-title">Fadilah Utami</h5>
                <p class="menu-card-nim">22323015</p>
            </div>

            <div class="member-card">
                <img src="img/lidia.jpg" alt="Lidia" class="menu-card-img" />
                <h5 class="menu-card-title">Lidia Sepianti</h5>
                <p class="menu-card-nim">22323020</p>
            </div>

            <div class="member-card">
                <img src="img/matjen.jpg" alt="Matjen" class="menu-card-img" />
                <h5 class="menu-card-title">Matjen Al Farizi Siregar</h5>
                <p class="menu-card-nim">22323022</p>
            </div>

            <div class="member-card">
                <img src="img/nanda.jpg" alt="Nanda" class="menu-card-img" />
                <h5 class="menu-card-title">Nanda Afriani</h5>
                <p class="menu-card-nim">22323025</p>
            </div>

            <div class="member-card">
                <img src="img/vinka.jpg" alt="vinka" class="menu-card-img" />
                <h5 class="menu-card-title">Vinka Nayla Elviani</h5>
                <p class="menu-card-nim">22323036</p>
            </div>

        </div>
    </section>
    <br>
    <!-- Member end -->

    <section id="member" class="member">
        <h2>THIS IS MEMBERS <span>TIF 22</span></h2>
        <br><br>

        <?php
// Tampilkan tabel jika $data['mbr'] ada dan tidak kosong
if (isset($data['mbr']) && !empty($data['mbr'])) : ?>
        <style>
        table {
            color: #fff;
            align-items: center;
            padding-left: 10%;
            font-size: 15px;
            height: 100vh;
            margin: 0;
        }

        th {
            border: 2px solid white;
            padding: 7px;

        }

        td {

            border: 2px solid white;
            border-collapse: collapse;
            padding: 7px;
        }

        tr {
            border: 2px solid white;
            text-align: center;
        }
        </style>
        <table>
            <ul class="list-group">
                <tr>
                    <th>No.</th>
                    <th>Nama</th>
                    <!-- <th>NIM</th>
                    <th>Email</th>
                    <th>Jenis Kelamin</th> -->

                </tr>
                <?php foreach ($data['mbr'] as $mbr) : ?>
                <tr>
                    <td style="width: 5%"><?php echo $mbr['nomor']; ?>.</td>
                    <td style="width: 55%; text-align: left; padding-left: 25px;"><?php echo $mbr['nama']; ?><a
                            href=" <?= BASEURL; ?>/member/bio/<?= $mbr['id']; ?>" class=""
                            style="float: right; background-color: var(--primary); color: white; text-decoration: none; padding: 5px 10px; border-radius: 5px;">Bio</a>
                    </td>


                    <!-- <td><?php echo $mbr['nim']; ?></td>
                    <td style="text-align: left; width: 31%; padding-left: 20px;"><?php echo $mbr['email']; ?></td>
                    <td><?php echo $mbr['jns_kelamin']; ?></td> -->
                </tr>
                <?php endforeach; ?>
            </ul>
        </table>
        <?php else : ?>
        <p>Data tidak ditemukan.</p>
        <?php endif; ?>
    </section>



    <!-- Member start -->
    <!-- <section id="member" class="member">
        <h2>THIS IS CLASS MEMBERS <span>TIF 22</span></h2>
        <div class="row">
            <div class="member-card">
                <img src="img/anisa.jpg" alt="Anisha" class="menu-card-img" />
                <h5 class="menu-card-title">Anisha Kartari</h5>
                <p class="menu-card-nim">22323009</p>
            </div>
            <div class="member-card">
                <img src="img/ayu.jpg" alt="Ayu" class="menu-card-img" />
                <h5 class="menu-card-title">Ayu Puspitasari</h5>
                <p class="menu-card-nim">22323010</p>
            </div>
            <div class="member-card">
                <img src="img/dewi.jpg" alt="Dewi" class="menu-card-img" />
                <h5 class="menu-card-title">Dewi Theresia Panjaitan</h5>
                <p class="menu-card-nim">22323011</p>
            </div>
            <div class="member-card">
                <img src="img/dinda.jpg" alt="Dinda" class="menu-card-img" />
                <h5 class="menu-card-title">Dinda Dwi Wanni Putri</h5>
                <p class="menu-card-nim">22323012</p>
            </div>
            <div class="member-card">
                <img src="img/eko.jpg" alt="Eko" class="menu-card-img" />
                <h5 class="menu-card-title">Eko Misbahul Anam</h5>
                <p class="menu-card-nim">22323013</p>
            </div>
            <div class="member-card">
                <img src="img/eva.jpg" alt="Eva" class="menu-card-img" />
                <h5 class="menu-card-title">Eva Fazria</h5>
                <p class="menu-card-nim">22323014</p>
            </div>
            <div class="member-card">
                <img src="img/fadilah.jpg" alt="Fadilah" class="menu-card-img" />
                <h5 class="menu-card-title">Fadilah Utami</h5>
                <p class="menu-card-nim">22323015</p>
            </div>
            <div class="member-card">
                <img src="img/ines.jpg" alt="Ines" class="menu-card-img" />
                <h5 class="menu-card-title">Ines Haya Mumtazah</h5>
                <p class="menu-card-nim">22323016</p>
            </div>
            <div class="member-card">
                <img src="img/jonatami.jpg" alt="Jonatami" class="menu-card-img" />
                <h5 class="menu-card-title">Jonatami Maif Rezi</h5>
                <p class="menu-card-nim">22323017</p>
            </div>
            <div class="member-card">
                <img src="img/khanifah.jpg" alt="Khanifah" class="menu-card-img" />
                <h5 class="menu-card-title">Khanifah Choirul Ummah</h5>
                <p class="menu-card-nim">22323018</p>
            </div>
            <div class="member-card">
                <img src="img/khoirul.jpg" alt="Khoirul" class="menu-card-img" />
                <h5 class="menu-card-title">Khoirul Adlin Hasibuan</h5>
                <p class="menu-card-nim">22323019</p>
            </div>
            <div class="member-card">
                <img src="img/lidia.jpg" alt="Lidia" class="menu-card-img" />
                <h5 class="menu-card-title">Lidia Sepianti</h5>
                <p class="menu-card-nim">22323020</p>
            </div>
            <div class="member-card">
                <img src="img/lucky.jpg" alt="Lucky" class="menu-card-img" />
                <h5 class="menu-card-title">Lucky Boy Pandapotan</h5>
                <p class="menu-card-nim">22323021</p>
            </div>
            <div class="member-card">
                <img src="img/matjen.jpg" alt="Matjen" class="menu-card-img" />
                <h5 class="menu-card-title">Matjen Al Farizi Siregar</h5>
                <p class="menu-card-nim">22323022</p>
            </div>
            <div class="member-card">
                <img src="img/miranti.jpg" alt="Miranti" class="menu-card-img" />
                <h5 class="menu-card-title">Miranti</h5>
                <p class="menu-card-nim">22323023</p>
            </div>
            <div class="member-card">
                <img src="img/najwa.jpg" alt="Najwa" class="menu-card-img" />
                <h5 class="menu-card-title">Najwa Auliyah</h5>
                <p class="menu-card-nim">22323024</p>
            </div>
            <div class="member-card">
                <img src="img/nanda.jpg" alt="Nanda" class="menu-card-img" />
                <h5 class="menu-card-title">Nanda Afriani</h5>
                <p class="menu-card-nim">22323025</p>
            </div>
            <div class="member-card">
                <img src="img/nurhidayah.jpg" alt="nurhidayah" class="menu-card-img" />
                <h5 class="menu-card-title">Nurhidayah Novitasari</h5>
                <p class="menu-card-nim">22323026</p>
            </div>
            <div class="member-card">
                <img src="img/nurul.jpg" alt="nurul" class="menu-card-img" />
                <h5 class="menu-card-title">Nurul Amelia</h5>
                <p class="menu-card-nim">22323027</p>
            </div>
            <div class="member-card">
                <img src="img/puteri.jpg" alt="puteri" class="menu-card-img" />
                <h5 class="menu-card-title">Puteri Yohana Br Sitompul</h5>
                <p class="menu-card-nim">22323028</p>
            </div>
            <div class="member-card">
                <img src="img/ratu.jpg" alt="ratu" class="menu-card-img" />
                <h5 class="menu-card-title">Ratu Natalia Marjani Ufayrah</h5>
                <p class="menu-card-nim">22323029</p>
            </div>
            <div class="member-card">
                <img src="img/reiza.jpg" alt="reiza" class="menu-card-img" />
                <h5 class="menu-card-title">Reiza Bias Utama</h5>
                <p class="menu-card-nim">22323030</p>
            </div>
            <div class="member-card">
                <img src="img/retno.jpg" alt="retno" class="menu-card-img" />
                <h5 class="menu-card-title">Retno Anggraini</h5>
                <p class="menu-card-nim">22323031</p>
            </div>
            <div class="member-card">
                <img src="img/rozik.jpg" alt="rozik" class="menu-card-img" />
                <h5 class="menu-card-title">Rozik Maulana</h5>
                <p class="menu-card-nim">22323032</p>
            </div>
            <div class="member-card">
                <img src="img/sanda.jpg" alt="sanda" class="menu-card-img" />
                <h5 class="menu-card-title">Sanda Haiki</h5>
                <p class="menu-card-nim">22323033</p>
            </div>
            <div class="member-card">
                <img src="img/suci.jpg" alt="suci" class="menu-card-img" />
                <h5 class="menu-card-title">Suci Wulan Dari</h5>
                <p class="menu-card-nim">22323034</p>
            </div>
            <div class="member-card">
                <img src="img/videa.jpg" alt="videa" class="menu-card-img" />
                <h5 class="menu-card-title">Videa Nurjanah</h5>
                <p class="menu-card-nim">22323035</p>
            </div>
            <div class="member-card">
                <img src="img/vinka.jpg" alt="vinka" class="menu-card-img" />
                <h5 class="menu-card-title">Vinka Nayla Elviani</h5>
                <p class="menu-card-nim">22323036</p>
            </div>
            <div class="member-card">
                <img src="img/yogi.jpg" alt="yogi" class="menu-card-img" />
                <h5 class="menu-card-title">Yogi Anggara</h5>
                <p class="menu-card-nim">22323037</p>
            </div>
            <div class="member-card">
                <img src="img/yosep.jpg" alt="yosep" class="menu-card-img" />
                <h5 class="menu-card-title">Yogi Sepdu Dehiya</h5>
                <p class="menu-card-nim">22323038</p>
            </div>
        </div>
    </section> -->
    <!-- Member end -->
    <!-- footer start-->
    <footer>
        <div class="social">
            <a href="https://www.instagram.com/tifb_22?igsh=NTVmejd4bWJiYWVi"><i data-feather="instagram"></i></a>
            <a href="https://wa.me/qr/LGRPSDS6FPBBK1"><i data-feather="phone-call"></i></a>
            <a href="https://github.com/Matjen-02"><i data-feather="github"></i></a>
        </div>

        <div class="links">
            <a href="<?= BASEURL; ?>/home">BERANDA</a>
            <a href="<?= BASEURL; ?>/about">VISI MISI</a>
            <a href="<?= BASEURL; ?>/admin">MEMBER</a>
            <a href="<?= BASEURL; ?>/kontak">KONTAK</a>
        </div>

        <div credit>
            <p>
                Created By
                <a href="https://instagram.com/matjen_alfarizi?utm_source=qr&igshid=MzNlNGNkZWQ4Mg==">Teknik
                    Informatika 2022</a>
                . | &copy; 2024.
            </p>
        </div>
    </footer>
    <!-- footer end -->

    <!-- Ikon -->
    <script>
    feather.replace();
    </script>

    <!-- My JS -->
    <script src="<?= BASEURL; ?>/js/script.js"></script>
    <script src="js/Web.js"></script>

</body>

</html>