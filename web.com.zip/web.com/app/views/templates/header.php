<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Halaman <?= $data['judul']; ?></title>
    <link rel="stylesheet" href="<?= BASEURL; ?>/css/bootstrap.css">
    <link rel="stylesheet" href="<?= BASEURL; ?>/dist/css/bootstrap.css">
    <script src="https://unpkg.com/feather-icons"></script>

</head>
<link rel="icon" href="<?= BASEURL; ?> /img/tif.png" type="jpg/png">

<body>

    <nav class="navbar navbar-expand-lg bg-body-dark ">
        <div class="container-fluid bg-dark">
            <a class="navbar-brand text-light" href="<?= BASEURL; ?>/home">TEKNIK <span>INFORMATIKA
                    2022</span></a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link active text-light" aria-current="page"
                            href="<?= BASEURL; ?>/admin">Kembali</a>
                    </li>
                </ul>
            </div>

            <div class="navbar-extra text-light">
                <a href="<?= BASEURL; ?>/login" class="text-light" id="user"><i data-feather="log-out"></i></a>
                <!-- <a href="#" id="menu" class="text-light"><i data-feather="menu"></i></a> -->
            </div>
    </nav>
    </div>
    </nav>