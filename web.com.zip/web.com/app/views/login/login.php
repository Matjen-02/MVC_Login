<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menu Login</title>
    <link rel="icon" href="../public/img/tif.png" type="jpg/png">
    <style>
    body {
        font-family: Arial, sans-serif;
        background-color: #f2f2f2;
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100vh;
        margin: 0;
        background-image: url('<?= BASEURL; ?> /img/z3.JPG');
        background-size: cover;
        background-position: center;
        background-repeat: no-repeat;
        height: 100vh;
        margin: 0;

    }

    .login-container {
        background-color: rgba(255, 255, 255, 0.9);
        padding: 20px;
        border-radius: 8px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.3);
        width: 300px;
    }

    .login-container h2 {
        margin-bottom: 15px;
        color: #333;
    }

    .form-group {
        margin-bottom: 15px;
    }

    .form-group label {
        display: block;
        margin-bottom: 5px;
        color: #333;
    }

    .form-group input {
        width: 100%;
        padding: 8px;
        border: 1px solid #ccc;
        border-radius: 4px;
        box-sizing: border-box;
    }

    .form-group input:focus {
        border-color: #007bff;
        outline: none;
    }

    .form-group button {
        width: 100%;
        padding: 10px;
        background-color: #778899;
        border: none;
        border-radius: 4px;
        color: #fff;
        font-size: 16px;
        cursor: pointer;
    }

    .form-group button:hover {
        background-color: black;
    }


    .flasher {
        position: fixed;
        color: white;
        top: 100px;
        right: 33.5%;
        z-index: 1050;
        min-width: 250px;
        opacity: 1;
        transition: opacity 0.5s ease-in-out;
    }
    </style>
</head>

<body>


    <div class="container">


        <div class="flasher">
            <?php Flasher::Message(); ?>
        </div>


        <div class="login-container col-lg-6" autocomplete="off">
            <h2>Silahkan Login</h2>
            <p>Masukkan Username & Password Anda !</p>
            <form action="<?= BASEURL; ?>/login/prosesLogin" method="post">
                <div class="form-group">
                    <label for="username">Username :</label>
                    <input type="text" id="username" name="username" required>
                </div>
                <div class="form-group">
                    <label for="password">Password :</label>
                    <input type="password" id="password" name="password" required>
                </div>
                <div class="form-group">
                    <button type="submit">Login</button>
                </div>

            </form>

        </div>
    </div>
</body>

</html>