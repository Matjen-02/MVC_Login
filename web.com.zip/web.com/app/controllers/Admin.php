<?php
class Admin extends Controller{
    public function index() {
        
        $data['judul'] = 'Member';
        $data['mbr'] = $this->model('MemberModel')->getAllMember();
        $this->view('admin/index', $data);
        // $this->view('templates/footer');
        
    }
}