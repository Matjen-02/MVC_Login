<?php

class Member extends Controller {

    public function index(){

        $data['judul'] = 'Daftar Member';
        $data['mbr'] = $this->model('MemberModel')->getAllMember();
        $this->view('templates/header', $data);
        $this->view('member/index', $data);
        $this->view('templates/footer');
    }

    public function bio($id){

        $data['judul'] = 'Bio Member';
        $data['mbr'] = $this->model('MemberModel')->getMemberById($id);

        $this->view('templates/header', $data);
        $this->view('member/bio', $data);
        $this->view('templates/footer');
    }

    public function tambah(){
        if( $this->model('MemberModel')->tambahDataMember($_POST) > 0 ){
            Flasher::setFlash(' Berhasil ', ' ditambahkan ', 'success');
            header('Location: ' . BASEURL . '/member');
            exit;
        } else {
            Flasher::setFlash(' Gagal ', ' ditambahkan ', 'danger');
            header('Location: ' . BASEURL . '/member');
            exit;
        }
    }

    public function hapus($id){
        if( $this->model('MemberModel')->hapusDataMember($id) > 0 ){
            Flasher::setFlash(' Berhasil ', ' dihapus ', 'success');
            header('Location: ' . BASEURL . '/member');
            exit;
        } else {
            Flasher::setFlash(' Gagal', ' dihapus ', 'danger');
            header('Location: ' . BASEURL . '/member');
            exit;
        }
    }

    public function getedit(){
       echo json_encode($this->model('MemberModel')->getMemberById($_POST['id']));
    }

    public function edit(){
        if( $this->model('MemberModel')->editDataMember($_POST) > 0 ){
            Flasher::setFlash(' Berhasil ', ' diedit ', 'success');
            header('Location: ' . BASEURL . '/member');
            exit;
        } else {
            Flasher::setFlash(' Gagal', ' diedit ', 'danger');
            header('Location: ' . BASEURL . '/member');
            exit;
        }
    }

    public function cari(){
        $data['judul'] = 'Daftar Member';
        $data['mbr'] = $this->model('MemberModel')->cariDataMember();
        $this->view('templates/header', $data);
        $this->view('member/index', $data);
        $this->view('templates/footer');
    }

}