// console.log("OK");
$(function () {
  $(".tombolTambahData").on("click", function () {
    $("#formModalLabel").html("Tambah Data Member");
    $(".modal-footer button[type=submit]").html("Tambah Data");
  });
  $(".tampilModalEdit").on("click", function () {
    // console.log("OK");
    $("#formModalLabel").html("Edit Data Member");
    $(".modal-footer button[type=submit]").html("Edit Data");
    $(".modal-body form").attr(
      "action",
      "http://web.com/public/tb_member/edit"
    );
    const id = $(this).data("id");

    $.ajax({
      url: "http://web.com/public/tb_member/getedit",
      data: { id: id },
      method: "post",
      dataType: "json",
      success: function (data) {
        $("#nomor").val(data.nomor);
        $("#nama").val(data.nama);
        $("#nim").val(data.nim);
        $("#email").val(data.email);
        $("#jns_kelamin").val(data.jns_kelamin);
        $("#id").val(data.id);
      },
    });
  });
});
